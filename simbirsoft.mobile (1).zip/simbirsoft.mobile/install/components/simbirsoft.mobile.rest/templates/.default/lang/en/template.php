<?
$MESS ['SIMBIRSOFT_MOBILE_MODULE_NOT_INSTALL'] = "simbirsoft.mobile module is not installed";
?>