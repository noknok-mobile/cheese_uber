<?
$MESS ['SIMBIRSOFT_MOBILE_MODULE_NOT_INSTALL'] = "Модуль simbirsoft.mobile не установлен";