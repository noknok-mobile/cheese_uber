<?
$MESS["BMNP_DEFAULT_TEMPLATE_NAME"]="Новые сообщения";
$MESS["BMNP_DEFAULT_TEMPLATE_DESCRIPTION"]="Выводит последние сообщения блогов текущего сайта";
$MESS["BMNP_NAME"]="Блоги";
?>