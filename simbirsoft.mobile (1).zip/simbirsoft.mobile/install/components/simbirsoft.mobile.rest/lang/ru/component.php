<?
$MESS['BLOG_MODULE_NOT_INSTALL']="Модуль блогов не установлен.";
?>
