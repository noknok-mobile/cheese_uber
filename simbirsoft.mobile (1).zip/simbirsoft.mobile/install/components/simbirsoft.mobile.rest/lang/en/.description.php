<?
$MESS["BMNP_DEFAULT_TEMPLATE_NAME"] = "Recent messages";
$MESS["BMNP_DEFAULT_TEMPLATE_DESCRIPTION"] = "Displays recent messages of all blogs";
$MESS["BMNP_NAME"] = "Blogs";
?>
