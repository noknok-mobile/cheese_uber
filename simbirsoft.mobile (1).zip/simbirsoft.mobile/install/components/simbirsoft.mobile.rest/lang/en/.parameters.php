<?
$MESS ['BMNP_MESSAGE_COUNT'] = "Messages per page";
$MESS ['BMNP_MESSAGE_LENGTH'] = "Maximum message display length";
$MESS ['BMNP_PATH_TO_BLOG'] = "Blog page path template";
$MESS ['BMNP_PATH_TO_POST'] = "Template of a blog message page";
$MESS ['BMNP_PATH_TO_USER'] = "Template of the blog user page path";
$MESS ['BMNP_PATH_TO_SMILE'] = "Path to folder with smileys, relative to the site root";
$MESS ['BMNP_BLOG_VAR'] = "Blog identifier variable";
$MESS ['BMNP_POST_VAR'] = "Blog message identifier variable";
$MESS ['BMNP_USER_VAR'] = "Blog user identifier variable";
$MESS ['BMNP_PAGE_VAR'] = "Page variable";
$MESS ['B_VARIABLE_ALIASES'] = "Variable aliases";
$MESS ['BMNP_PREVIEW_WIDTH'] = "Preview image width";
$MESS ['BMNP_PREVIEW_HEIGHT'] = "Preview image height";
$MESS ['BC_DATE_TIME_FORMAT'] = "Date and time format";
$MESS ['BLG_GROUP_ID'] = "Blogs group";
$MESS ['BLG_BLOG_URL'] = "Blog url";
$MESS ['BMNP_PATH_TO_GROUP_BLOG_POST'] = "Group Blog Post Page URL Template";
$MESS ['BMNP_USE_SOCNET'] = "Used in Social Network";
?>