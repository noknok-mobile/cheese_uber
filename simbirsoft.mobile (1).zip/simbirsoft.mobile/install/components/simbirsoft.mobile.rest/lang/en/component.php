<?
$MESS['BLOG_MODULE_NOT_INSTALL'] = "Blog module is not installed.";
?>
