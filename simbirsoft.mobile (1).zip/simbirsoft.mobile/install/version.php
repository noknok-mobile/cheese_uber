<?
$arModuleVersion = array(
    "VERSION" => "1.0.2",
    "VERSION_DATE" => "2019-08-26 15:30:00"
);
