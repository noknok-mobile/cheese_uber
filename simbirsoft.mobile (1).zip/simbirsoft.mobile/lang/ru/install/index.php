<?
/*index*/
$MESS["MOBILE_MODULE_NAME"] = "Mobile REST API";
$MESS["MODULE_DESCRIPTION"] = "Модуль REST сервиса для мобильного приложения";
$MESS["PARTNER_NAME"] = "Simbirsoft";
$MESS["PARTNER_URI"] = "http://www.simbirsoft.com";
$MESS["D7_INSTALL_ERROR_VERSION"] = "Модуль для ядра D7, с 14.0.0 версии Битрикса";
$MESS["DENIED"] = "Доступ закрыт";
$MESS["DENIED_READ_COMPONENT"] = "Доступ к компонентам";
$MESS["WRITE_SETTINS"] = "Доступ к настройкам";
$MESS["FULL"] = "Полный доступ";